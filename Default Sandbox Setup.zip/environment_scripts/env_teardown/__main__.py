from environment_scripts.env_teardown.teardown_script import EnvironmentTeardown


def main():
    EnvironmentTeardown().execute()

if __name__ == "__main__":
    main()
